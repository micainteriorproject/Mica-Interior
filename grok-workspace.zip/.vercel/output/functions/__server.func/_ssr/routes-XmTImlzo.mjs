import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { i as require_jsx_runtime, r as Slot, t as Label } from "../_libs/@radix-ui/react-label+[...].mjs";
import { a as Copy, i as Instagram, n as Plus, o as Check, r as Minus, s as ArrowDown } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-XmTImlzo.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var badgeVariants = cva("inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium tracking-wide", {
	variants: { variant: {
		default: "bg-primary text-primary-fg",
		muted: "bg-surface text-muted",
		outline: "border border-border bg-elevated text-fg"
	} },
	defaultVariants: { variant: "muted" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[opacity,transform,background-color,color,border-color] duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary disabled:pointer-events-none disabled:opacity-40 active:scale-press [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-primary text-primary-fg hover:opacity-90",
			invert: "bg-bg text-fg hover:opacity-90",
			outline: "border border-border bg-elevated text-fg hover:bg-surface",
			ghost: "text-fg hover:bg-surface",
			link: "rounded-none text-fg underline-offset-4 hover:underline"
		},
		size: {
			default: "h-11 px-5",
			sm: "h-9 px-3 text-sm",
			lg: "h-12 px-6",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
var INSTAGRAM_HANDLE = "narakitchen.id";
var INSTAGRAM_URL = `https://www.instagram.com/${INSTAGRAM_HANDLE}/`;
var INSTAGRAM_DM_URL = `https://ig.me/m/${INSTAGRAM_HANDLE}`;
var COLLECTIONS = [
	{
		id: "sora",
		name: "Sora",
		style: "Japandi",
		finish: "HPL",
		pricePerMeter: 48e5,
		leadWeeks: "4–5 minggu",
		blurb: "Oak hangat, rak terbuka, dan kuarsa pucat. Tenang seperti rumah di pagi hari.",
		image: "/kitchens/sora.jpg",
		alt: "Kitchen set Sora bergaya japandi dengan kabinet oak dan rak keramik"
	},
	{
		id: "lumen",
		name: "Lumen",
		style: "Modern",
		finish: "Akrilik",
		pricePerMeter: 72e5,
		leadWeeks: "5–6 minggu",
		blurb: "Slab putih tanpa handle, profil tipis, tap hitam. Dapur yang rapi tanpa ribet.",
		image: "/kitchens/lumen.jpg",
		alt: "Kitchen set Lumen modern putih handleless dengan marmer dan keran hitam"
	},
	{
		id: "arka",
		name: "Arka",
		style: "Industrial",
		finish: "HPL",
		pricePerMeter: 54e5,
		leadWeeks: "4–5 minggu",
		blurb: "Walnut asap, granit hitam, cahaya samping. Tegas, hangat, dan tahan lama.",
		image: "/kitchens/arka.jpg",
		alt: "Kitchen set Arka walnut gelap dengan granit hitam dan lampu gantung industrial"
	},
	{
		id: "mira",
		name: "Mira",
		style: "Klasik",
		finish: "Duco",
		pricePerMeter: 65e5,
		leadWeeks: "6–7 minggu",
		blurb: "Shaker krem, island kayu, wastafel farmhouse. Elegan tanpa terasa kaku.",
		image: "/kitchens/mira.jpg",
		alt: "Kitchen set Mira klasik krem dengan pintu shaker dan island kayu"
	},
	{
		id: "sage",
		name: "Sage",
		style: "Tropis",
		finish: "Duco",
		pricePerMeter: 68e5,
		leadWeeks: "6–7 minggu",
		blurb: "Hijau sage matte, oak pucat, lantai terakota. Cocok untuk rumah yang banyak cahaya.",
		image: "/kitchens/sage.jpg",
		alt: "Kitchen set Sage hijau sage dengan rak oak dan lantai terakota"
	},
	{
		id: "batu",
		name: "Batu",
		style: "Modern",
		finish: "HPL",
		pricePerMeter: 59e5,
		leadWeeks: "4–5 minggu",
		blurb: "Abu batu, kuarsa urat, kaca fluted. Quiet luxury untuk dapur compact.",
		image: "/kitchens/batu.jpg",
		alt: "Kitchen set Batu charcoal dengan counter kuarsa dan kaca fluted"
	}
];
var STYLES = [
	"Semua",
	"Japandi",
	"Modern",
	"Industrial",
	"Klasik",
	"Tropis"
];
var LAYOUTS = [
	{
		id: "lurus",
		label: "Lurus",
		hint: "Satu dinding"
	},
	{
		id: "l",
		label: "Huruf L",
		hint: "Sudut dapur"
	},
	{
		id: "u",
		label: "Huruf U",
		hint: "Tiga sisi"
	},
	{
		id: "paralel",
		label: "Paralel",
		hint: "Dua baris"
	},
	{
		id: "pulau",
		label: "Pulau",
		hint: "Plus island"
	}
];
function getCollection(id) {
	return COLLECTIONS.find((item) => item.id === id) ?? COLLECTIONS[0];
}
function formatRupiah(value) {
	return new Intl.NumberFormat("id-ID", {
		style: "currency",
		currency: "IDR",
		maximumFractionDigits: 0
	}).format(value);
}
function estimatePrice(pricePerMeter, lengthM) {
	const meters = Math.round(lengthM * 2) / 2;
	return Math.round(pricePerMeter * meters);
}
function buildOrderMessage(input) {
	const estimate = estimatePrice(input.collection.pricePerMeter, input.lengthM);
	const length = input.lengthM.toLocaleString("id-ID", {
		minimumFractionDigits: input.lengthM % 1 === 0 ? 0 : 1,
		maximumFractionDigits: 1
	});
	const notes = input.notes.trim() || "—";
	return [
		"Halo NARA Kitchen, saya ingin pesan kitchen set.",
		"",
		`Nama: ${input.name.trim()}`,
		`Kota: ${input.city.trim()}`,
		`Koleksi: ${input.collection.name} — ${input.collection.style} (${input.collection.finish})`,
		`Layout: ${input.layout.label}`,
		`Panjang kabinet: ${length} m`,
		`Estimasi: ${formatRupiah(estimate)}`,
		`Catatan: ${notes}`,
		"",
		"Mohon info ketersediaan survey dan jadwal pengerjaan."
	].join("\n");
}
async function copyText(value) {
	try {
		await navigator.clipboard.writeText(value);
		return true;
	} catch {
		return false;
	}
}
var useOrder = create((set) => ({
	collectionId: COLLECTIONS[0].id,
	lengthM: 3,
	layout: "lurus",
	name: "",
	city: "",
	notes: "",
	selectCollection: (id) => set({ collectionId: id }),
	patch: (next) => set(next)
}));
function scrollToOrder() {
	const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
	document.getElementById("pesan")?.scrollIntoView({ behavior: reduce ? "auto" : "smooth" });
}
function Collections() {
	const [style, setStyle] = (0, import_react.useState)("Semua");
	const selectedId = useOrder((s) => s.collectionId);
	const selectCollection = useOrder((s) => s.selectCollection);
	const items = COLLECTIONS.filter((item) => style === "Semua" || item.style === style);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "koleksi",
		className: "mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-label text-muted",
						children: "Koleksi"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-3 font-display text-3xl font-medium tracking-tight sm:text-4xl",
						children: "Enam dapur, satu alur pesan."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-muted",
						children: "Harga mulai dari finishing kabinet per meter. Top table, handle, dan pekerjaan sipil dihitung setelah survey."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "-mx-4 mt-8 flex gap-2 overflow-x-auto px-4 pb-1 sm:mx-0 sm:flex-wrap sm:overflow-visible sm:px-0",
				children: STYLES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setStyle(item),
					className: cn("h-11 shrink-0 rounded-full border px-4 text-sm font-medium transition-colors duration-[var(--motion-quick)]", style === item ? "border-primary bg-primary text-primary-fg" : "border-border bg-elevated text-muted hover:text-fg"),
					children: item
				}, item))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3",
				children: items.map((item) => {
					const active = selectedId === item.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: cn("flex flex-col overflow-hidden rounded-2xl border bg-elevated transition-colors duration-[var(--motion-fast)]", active ? "border-primary" : "border-border"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative aspect-photo overflow-hidden bg-surface",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: item.image,
								alt: item.alt,
								className: "size-full object-cover transition-transform duration-[var(--motion-slow)] ease-[var(--ease-smooth-out)] hover:scale-105"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								className: "absolute left-3 top-3 bg-elevated/95 text-fg",
								children: item.style
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-1 flex-col gap-4 p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-display text-2xl font-medium tracking-tight",
										children: item.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-sm text-muted",
										children: [
											item.finish,
											" · ",
											item.leadWeeks
										]
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "text-right text-sm font-medium tabular-nums",
										children: [formatRupiah(item.pricePerMeter), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-xs font-normal text-muted",
											children: "/ meter"
										})]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm leading-relaxed text-muted",
									children: item.blurb
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									className: "mt-auto w-full",
									variant: active ? "default" : "outline",
									onClick: () => {
										selectCollection(item.id);
										scrollToOrder();
									},
									children: active ? "Dipilih · lanjut pesan" : "Pesan koleksi ini"
								})
							]
						})]
					}, item.id);
				})
			})
		]
	});
}
function Hero() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "atas",
		className: "relative h-hero overflow-hidden bg-fg text-bg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: "/kitchens/hero.jpg",
				alt: "Dapur japandi NARA dengan island batu dan kabinet oak",
				className: "absolute inset-0 size-full object-cover"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-fg via-fg/45 to-fg/20" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative z-10 mx-auto flex h-full max-w-6xl flex-col justify-end gap-6 px-4 pb-12 sm:px-6 sm:pb-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-label text-bg/80",
						children: "Studio kitchen set · Jakarta"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "max-w-2xl font-display text-4xl font-medium leading-tight tracking-tight text-bg sm:text-5xl lg:text-6xl",
						children: "Kitchen set custom. Pesan lewat Instagram."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-lg text-base leading-relaxed text-bg/80 sm:text-lg",
						children: "Enam koleksi siap pakai. Hitung estimasi per meter, kirim ringkasan ke DM, lalu kami survey ke rumah."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-3 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "invert",
							size: "lg",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: "#koleksi",
								children: "Lihat koleksi"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "lg",
							className: "border-bg/30 bg-transparent text-bg hover:bg-bg/10",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "#pesan",
								children: ["Hitung estimasi", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, {})]
							})
						})]
					})
				]
			})
		]
	});
}
function LayoutIcon({ type }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: "size-8",
		fill: "currentColor",
		"aria-hidden": "true",
		children: [
			type === "lurus" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "4",
				y: "13",
				width: "24",
				height: "6",
				rx: "1"
			}) : null,
			type === "l" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "4",
				y: "18",
				width: "24",
				height: "6",
				rx: "1"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "4",
				y: "8",
				width: "6",
				height: "16",
				rx: "1"
			})] }) : null,
			type === "u" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "4",
					y: "20",
					width: "24",
					height: "6",
					rx: "1"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "4",
					y: "8",
					width: "6",
					height: "18",
					rx: "1"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					x: "22",
					y: "8",
					width: "6",
					height: "18",
					rx: "1"
				})
			] }) : null,
			type === "paralel" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "4",
				y: "7",
				width: "24",
				height: "6",
				rx: "1"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "4",
				y: "19",
				width: "24",
				height: "6",
				rx: "1"
			})] }) : null,
			type === "pulau" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "4",
				y: "7",
				width: "24",
				height: "5",
				rx: "1"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "10",
				y: "18",
				width: "12",
				height: "7",
				rx: "1"
			})] }) : null
		]
	});
}
function Input({ className, type, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("h-11 w-full rounded-md border border-border bg-elevated px-3 text-sm text-fg shadow-none outline-none transition-[border-color,box-shadow] duration-[var(--motion-quick)] placeholder:text-faint focus-visible:border-primary focus-visible:ring-2 focus-visible:ring-primary/20 disabled:opacity-50", className),
		...props
	});
}
function Label$1({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
		className: cn("text-sm font-medium text-fg", className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("min-h-24 w-full rounded-lg border border-border bg-elevated px-3 py-2.5 text-sm text-fg outline-none transition-[border-color,box-shadow] duration-[var(--motion-quick)] placeholder:text-faint focus-visible:border-primary focus-visible:ring-2 focus-visible:ring-primary/20 disabled:opacity-50", className),
		...props
	});
}
var MIN_LENGTH = 1.5;
var MAX_LENGTH = 12;
var STEP = .5;
function clampLength(value) {
	const snapped = Math.round(value / STEP) * STEP;
	return Math.min(MAX_LENGTH, Math.max(MIN_LENGTH, snapped));
}
function OrderPanel() {
	const order = useOrder();
	const collection = getCollection(order.collectionId);
	const layout = LAYOUTS.find((item) => item.id === order.layout) ?? LAYOUTS[0];
	const estimate = estimatePrice(collection.pricePerMeter, order.lengthM);
	const [errors, setErrors] = (0, import_react.useState)({});
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [draft, setDraft] = (0, import_react.useState)(null);
	const lengthLabel = (0, import_react.useMemo)(() => order.lengthM.toLocaleString("id-ID", {
		minimumFractionDigits: order.lengthM % 1 === 0 ? 0 : 1,
		maximumFractionDigits: 1
	}), [order.lengthM]);
	function validate() {
		const next = {};
		if (order.name.trim().length < 2) next.name = "Isi nama lengkap.";
		if (order.city.trim().length < 2) next.city = "Isi kota atau area.";
		setErrors(next);
		return Object.keys(next).length === 0;
	}
	async function submit(event) {
		event.preventDefault();
		if (!validate()) return;
		const message = buildOrderMessage({
			name: order.name,
			city: order.city,
			collection,
			layout,
			lengthM: order.lengthM,
			notes: order.notes
		});
		const ok = await copyText(message);
		setDraft(message);
		setCopied(ok);
	}
	async function recopy() {
		if (!draft) return;
		const ok = await copyText(draft);
		setCopied(ok);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		id: "pesan",
		className: "mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-label text-muted",
					children: "Pemesanan"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-3xl font-medium tracking-tight sm:text-4xl",
					children: "Hitung estimasi, kirim ke Instagram."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-muted",
					children: [
						"Ringkasan otomatis disalin. Kami buka DM @",
						INSTAGRAM_HANDLE,
						" — tempel, lalu kirim."
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-10 grid items-start gap-6 lg:grid-cols-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: submit,
				className: "flex flex-col gap-6 rounded-2xl border border-border bg-elevated p-5 sm:p-6 lg:col-span-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label$1, {
							htmlFor: "koleksi-select",
							children: "Koleksi"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							id: "koleksi-select",
							value: order.collectionId,
							onChange: (event) => order.selectCollection(event.target.value),
							className: "h-11 w-full rounded-md border border-border bg-elevated px-3 text-sm text-fg outline-none focus-visible:border-primary focus-visible:ring-2 focus-visible:ring-primary/20",
							children: COLLECTIONS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: item.id,
								children: [
									item.name,
									" · ",
									item.style,
									" · ",
									formatRupiah(item.pricePerMeter),
									"/m"
								]
							}, item.id))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label$1, { children: "Layout dapur" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5",
							children: LAYOUTS.map((item) => {
								const active = order.layout === item.id;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => order.patch({ layout: item.id }),
									className: cn("flex min-h-24 flex-col items-center justify-center gap-1 rounded-lg border px-2 py-3 text-center transition-colors duration-[var(--motion-quick)]", active ? "border-primary bg-primary text-primary-fg" : "border-border bg-bg text-muted hover:text-fg"),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LayoutIcon, { type: item.id }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-sm font-medium",
											children: item.label
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: cn("text-xs", active ? "text-primary-fg/70" : "text-faint"),
											children: item.hint
										})
									]
								}, item.id);
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label$1, {
									htmlFor: "panjang",
									children: "Panjang kabinet"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-sm font-medium tabular-nums",
									children: [lengthLabel, " m"]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										variant: "outline",
										size: "icon",
										"aria-label": "Kurangi setengah meter",
										onClick: () => order.patch({ lengthM: clampLength(order.lengthM - STEP) }),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, {})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										id: "panjang",
										type: "number",
										min: MIN_LENGTH,
										max: MAX_LENGTH,
										step: STEP,
										inputMode: "decimal",
										value: order.lengthM,
										onChange: (event) => {
											const next = Number(event.target.value);
											if (Number.isFinite(next)) order.patch({ lengthM: clampLength(next) });
										},
										className: "text-center tabular-nums"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										type: "button",
										variant: "outline",
										size: "icon",
										"aria-label": "Tambah setengah meter",
										onClick: () => order.patch({ lengthM: clampLength(order.lengthM + STEP) }),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {})
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: "Ukur sisi dinding yang akan dipasang kabinet, dari ujung ke ujung."
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label$1, {
									htmlFor: "nama",
									children: "Nama"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "nama",
									autoComplete: "name",
									placeholder: "Nama pemesan",
									value: order.name,
									onChange: (event) => order.patch({ name: event.target.value }),
									"aria-invalid": Boolean(errors.name)
								}),
								errors.name ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium text-fg",
									children: errors.name
								}) : null
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label$1, {
									htmlFor: "kota",
									children: "Kota / area"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									id: "kota",
									autoComplete: "address-level2",
									placeholder: "Contoh: Tangerang Selatan",
									value: order.city,
									onChange: (event) => order.patch({ city: event.target.value }),
									"aria-invalid": Boolean(errors.city)
								}),
								errors.city ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium text-fg",
									children: errors.city
								}) : null
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label$1, {
							htmlFor: "catatan",
							children: "Catatan dapur"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							id: "catatan",
							placeholder: "Ukuran ruangan, posisi jendela, mau island, atau warna custom.",
							value: order.notes,
							onChange: (event) => order.patch({ notes: event.target.value })
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "submit",
						size: "lg",
						className: "w-full",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Instagram, {}), "Pesan via Instagram"]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "rounded-2xl border border-border bg-elevated lg:sticky lg:top-24 lg:col-span-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "relative aspect-photo overflow-hidden rounded-t-2xl bg-surface",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: collection.image,
						alt: collection.alt,
						className: "size-full object-cover"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-4 p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium uppercase tracking-label text-muted",
								children: "Estimasi"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "mt-1 font-display text-2xl font-medium tracking-tight",
								children: collection.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted",
								children: [
									collection.style,
									" · ",
									collection.finish,
									" · ",
									layout.label
								]
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-3xl font-medium tabular-nums tracking-tight",
							children: formatRupiah(estimate)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs leading-relaxed text-muted",
							children: [
								lengthLabel,
								" m × ",
								formatRupiah(collection.pricePerMeter),
								". Belum termasuk top table, ongkir, dan pekerjaan sipil. Harga final setelah survey."
							]
						}),
						draft ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-border bg-bg p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "flex items-center gap-2 text-sm font-medium",
									children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), copied ? "Ringkasan sudah disalin" : "Salin ringkasan, lalu buka DM"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
									className: "mt-2 max-h-40 overflow-auto whitespace-pre-wrap font-sans text-xs leading-relaxed text-muted",
									children: draft
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 grid gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										type: "button",
										variant: "outline",
										onClick: recopy,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {}), "Salin ulang"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
											href: INSTAGRAM_DM_URL,
											target: "_blank",
											rel: "noreferrer",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Instagram, {}), "Buka DM Instagram"]
										})
									})]
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Isi nama dan kota, lalu kirim. Studio membalas di Instagram."
						})
					]
				})]
			})]
		})]
	});
}
var steps = [
	{
		n: "01",
		title: "Pilih koleksi",
		body: "Enam finishing siap pakai. Warna dan handle masih bisa disesuaikan setelah survey."
	},
	{
		n: "02",
		title: "Hitung ukuran",
		body: "Masukkan panjang kabinet. Estimasi muncul langsung, tanpa menunggu chat admin."
	},
	{
		n: "03",
		title: "Kirim ke Instagram",
		body: "Ringkasan disalin, DM studio terbuka. Tempel, kirim, selesai."
	},
	{
		n: "04",
		title: "Survey & gambar kerja",
		body: "Tim ukur di lokasi, kunci material, lalu produksi. Jabodetabek survey gratis."
	}
];
function Process() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		id: "cara",
		className: "border-y border-border bg-surface",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-label text-muted",
					children: "Cara kerja"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 max-w-lg font-display text-3xl font-medium tracking-tight sm:text-4xl",
					children: "Dari foto dapur sampai DM, empat langkah."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-4",
					children: steps.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-col gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-3xl font-medium text-primary/70",
								children: step.n
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-lg font-medium",
								children: step.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm leading-relaxed text-muted",
								children: step.body
							})
						]
					}, step.n))
				})
			]
		})
	});
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
		className: "border-t border-border bg-fg text-bg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex max-w-6xl flex-col gap-8 px-4 py-12 sm:px-6 sm:py-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col justify-between gap-8 sm:flex-row sm:items-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-3xl font-medium tracking-tight",
					children: "NARA"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-sm text-sm leading-relaxed text-bg/70",
					children: "Studio kitchen set custom. Produksi di Tangerang, survey Jabodetabek, pemesanan lewat Instagram."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: INSTAGRAM_URL,
					target: "_blank",
					rel: "noreferrer",
					className: "inline-flex h-11 items-center gap-2 text-sm font-medium text-bg hover:opacity-80",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Instagram, { className: "size-4" }),
						"@",
						INSTAGRAM_HANDLE
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-bg/50",
				children: "Estimasi di situs ini adalah acuan kabinet. Harga final setelah pengukuran."
			})]
		})
	});
}
var links = [
	{
		href: "#koleksi",
		label: "Koleksi"
	},
	{
		href: "#cara",
		label: "Cara kerja"
	},
	{
		href: "#pesan",
		label: "Pesan"
	}
];
function SiteHeader() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "sticky top-0 z-40 border-b border-border bg-bg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: "#atas",
					className: "flex items-baseline gap-2 text-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-xl font-medium tracking-tight",
						children: "NARA"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs font-medium uppercase tracking-label text-muted",
						children: "Kitchen"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-8 md:flex",
					"aria-label": "Utama",
					children: links.map((link) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: link.href,
						className: "text-sm font-medium text-muted transition-colors duration-[var(--motion-quick)] hover:text-fg",
						children: link.label
					}, link.href))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						size: "icon",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: INSTAGRAM_URL,
							target: "_blank",
							rel: "noreferrer",
							"aria-label": "Instagram NARA Kitchen",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Instagram, {})
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "#pesan",
							children: "Pesan"
						})
					})]
				})
			]
		})
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-svh bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Collections, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Process, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrderPanel, {})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { Home as component };
