import { create } from "zustand";
import { COLLECTIONS, type LayoutId } from "@/lib/kitchen";

type OrderState = {
  collectionId: string;
  lengthM: number;
  layout: LayoutId;
  name: string;
  city: string;
  notes: string;
  selectCollection: (id: string) => void;
  patch: (next: Partial<Pick<OrderState, "lengthM" | "layout" | "name" | "city" | "notes">>) => void;
};

export const useOrder = create<OrderState>((set) => ({
  collectionId: COLLECTIONS[0].id,
  lengthM: 3,
  layout: "lurus",
  name: "",
  city: "",
  notes: "",
  selectCollection: (id) => set({ collectionId: id }),
  patch: (next) => set(next),
}));
