export type Finish = "HPL" | "Duco" | "Akrilik";

export type Collection = {
  id: string;
  name: string;
  style: string;
  finish: Finish;
  pricePerMeter: number;
  leadWeeks: string;
  blurb: string;
  image: string;
  alt: string;
};

export const BRAND_NAME = "Mica Interior Project";
export const INSTAGRAM_HANDLE = "micainteriorproject";
export const INSTAGRAM_URL = `https://www.instagram.com/${INSTAGRAM_HANDLE}/`;
export const INSTAGRAM_DM_URL = `https://ig.me/m/${INSTAGRAM_HANDLE}`;

export const COLLECTIONS: Collection[] = [
  {
    id: "sora",
    name: "Sora",
    style: "Japandi",
    finish: "HPL",
    pricePerMeter: 4_800_000,
    leadWeeks: "4–5 minggu",
    blurb: "Oak hangat, rak terbuka, dan kuarsa pucat. Tenang seperti rumah di pagi hari.",
    image: "/kitchens/sora.jpg",
    alt: "Kitchen set Sora bergaya japandi dengan kabinet oak dan rak keramik",
  },
  {
    id: "lumen",
    name: "Lumen",
    style: "Modern",
    finish: "Akrilik",
    pricePerMeter: 7_200_000,
    leadWeeks: "5–6 minggu",
    blurb: "Slab putih tanpa handle, profil tipis, tap hitam. Dapur yang rapi tanpa ribet.",
    image: "/kitchens/lumen.jpg",
    alt: "Kitchen set Lumen modern putih handleless dengan marmer dan keran hitam",
  },
  {
    id: "arka",
    name: "Arka",
    style: "Industrial",
    finish: "HPL",
    pricePerMeter: 5_400_000,
    leadWeeks: "4–5 minggu",
    blurb: "Walnut asap, granit hitam, cahaya samping. Tegas, hangat, dan tahan lama.",
    image: "/kitchens/arka.jpg",
    alt: "Kitchen set Arka walnut gelap dengan granit hitam dan lampu gantung industrial",
  },
  {
    id: "mira",
    name: "Mira",
    style: "Klasik",
    finish: "Duco",
    pricePerMeter: 6_500_000,
    leadWeeks: "6–7 minggu",
    blurb: "Shaker krem, island kayu, wastafel farmhouse. Elegan tanpa terasa kaku.",
    image: "/kitchens/mira.jpg",
    alt: "Kitchen set Mira klasik krem dengan pintu shaker dan island kayu",
  },
  {
    id: "sage",
    name: "Sage",
    style: "Tropis",
    finish: "Duco",
    pricePerMeter: 6_800_000,
    leadWeeks: "6–7 minggu",
    blurb: "Hijau sage matte, oak pucat, lantai terakota. Cocok untuk rumah yang banyak cahaya.",
    image: "/kitchens/sage.jpg",
    alt: "Kitchen set Sage hijau sage dengan rak oak dan lantai terakota",
  },
  {
    id: "batu",
    name: "Batu",
    style: "Modern",
    finish: "HPL",
    pricePerMeter: 5_900_000,
    leadWeeks: "4–5 minggu",
    blurb: "Abu batu, kuarsa urat, kaca fluted. Quiet luxury untuk dapur compact.",
    image: "/kitchens/batu.jpg",
    alt: "Kitchen set Batu charcoal dengan counter kuarsa dan kaca fluted",
  },
];

export const STYLES = ["Semua", "Japandi", "Modern", "Industrial", "Klasik", "Tropis"] as const;
export type StyleFilter = (typeof STYLES)[number];

export const LAYOUTS = [
  { id: "lurus", label: "Lurus", hint: "Satu dinding" },
  { id: "l", label: "Huruf L", hint: "Sudut dapur" },
  { id: "u", label: "Huruf U", hint: "Tiga sisi" },
  { id: "paralel", label: "Paralel", hint: "Dua baris" },
  { id: "pulau", label: "Pulau", hint: "Plus island" },
] as const;

export type LayoutId = (typeof LAYOUTS)[number]["id"];

export function getCollection(id: string) {
  return COLLECTIONS.find((item) => item.id === id) ?? COLLECTIONS[0];
}

export function formatRupiah(value: number) {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    maximumFractionDigits: 0,
  }).format(value);
}

export function estimatePrice(pricePerMeter: number, lengthM: number) {
  const meters = Math.round(lengthM * 2) / 2;
  return Math.round(pricePerMeter * meters);
}

export function buildOrderMessage(input: {
  name: string;
  city: string;
  collection: Collection;
  layout: (typeof LAYOUTS)[number];
  lengthM: number;
  notes: string;
}) {
  const estimate = estimatePrice(input.collection.pricePerMeter, input.lengthM);
  const length = input.lengthM.toLocaleString("id-ID", {
    minimumFractionDigits: input.lengthM % 1 === 0 ? 0 : 1,
    maximumFractionDigits: 1,
  });
  const notes = input.notes.trim() || "—";

  return [
    "Halo Mica Interior Project, saya ingin pesan kitchen set.",
    "",
    `Nama: ${input.name.trim()}`,
    `Kota: ${input.city.trim()}`,
    `Koleksi: ${input.collection.name} — ${input.collection.style} (${input.collection.finish})`,
    `Layout: ${input.layout.label}`,
    `Panjang kabinet: ${length} m`,
    `Estimasi: ${formatRupiah(estimate)}`,
    `Catatan: ${notes}`,
    "",
    "Mohon info ketersediaan survey dan jadwal pengerjaan.",
  ].join("\n");
}

export async function copyText(value: string) {
  try {
    await navigator.clipboard.writeText(value);
    return true;
  } catch {
    return false;
  }
}
