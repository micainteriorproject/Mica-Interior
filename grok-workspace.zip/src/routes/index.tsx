import { createFileRoute } from "@tanstack/react-router";
import { Collections } from "@/components/collections";
import { Hero } from "@/components/hero";
import { OrderPanel } from "@/components/order-panel";
import { Process } from "@/components/process";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <div className="min-h-svh bg-bg text-fg">
      <SiteHeader />
      <main>
        <Hero />
        <Collections />
        <Process />
        <OrderPanel />
      </main>
      <SiteFooter />
    </div>
  );
}
