import { useMemo, useState, type FormEvent } from "react";
import { Check, Copy, Instagram, Minus, Plus } from "lucide-react";
import { LayoutIcon } from "@/components/layout-icon";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  COLLECTIONS,
  INSTAGRAM_DM_URL,
  INSTAGRAM_HANDLE,
  LAYOUTS,
  buildOrderMessage,
  copyText,
  estimatePrice,
  formatRupiah,
  getCollection,
} from "@/lib/kitchen";
import { useOrder } from "@/lib/order-store";
import { cn } from "@/lib/utils";

const MIN_LENGTH = 1.5;
const MAX_LENGTH = 12;
const STEP = 0.5;

function clampLength(value: number) {
  const snapped = Math.round(value / STEP) * STEP;
  return Math.min(MAX_LENGTH, Math.max(MIN_LENGTH, snapped));
}

export function OrderPanel() {
  const order = useOrder();
  const collection = getCollection(order.collectionId);
  const layout = LAYOUTS.find((item) => item.id === order.layout) ?? LAYOUTS[0];
  const estimate = estimatePrice(collection.pricePerMeter, order.lengthM);

  const [errors, setErrors] = useState<{ name?: string; city?: string }>({});
  const [copied, setCopied] = useState(false);
  const [draft, setDraft] = useState<string | null>(null);

  const lengthLabel = useMemo(
    () =>
      order.lengthM.toLocaleString("id-ID", {
        minimumFractionDigits: order.lengthM % 1 === 0 ? 0 : 1,
        maximumFractionDigits: 1,
      }),
    [order.lengthM],
  );

  function validate() {
    const next: { name?: string; city?: string } = {};
    if (order.name.trim().length < 2) next.name = "Isi nama lengkap.";
    if (order.city.trim().length < 2) next.city = "Isi kota atau area.";
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (!validate()) return;

    const message = buildOrderMessage({
      name: order.name,
      city: order.city,
      collection,
      layout,
      lengthM: order.lengthM,
      notes: order.notes,
    });
    const ok = await copyText(message);
    setDraft(message);
    setCopied(ok);
  }

  async function recopy() {
    if (!draft) return;
    const ok = await copyText(draft);
    setCopied(ok);
  }

  return (
    <section id="pesan" className="mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24">
      <div className="max-w-xl">
        <p className="text-xs font-medium uppercase tracking-label text-muted">Pemesanan</p>
        <h2 className="mt-3 font-display text-3xl font-medium tracking-tight sm:text-4xl">
          Hitung estimasi, kirim ke Instagram.
        </h2>
        <p className="mt-3 text-muted">
          Ringkasan otomatis disalin. Kami buka DM @{INSTAGRAM_HANDLE} — tempel, lalu kirim.
        </p>
      </div>

      <div className="mt-10 grid items-start gap-6 lg:grid-cols-5">
        <form
          onSubmit={submit}
          className="flex flex-col gap-6 rounded-2xl border border-border bg-elevated p-5 sm:p-6 lg:col-span-3"
        >
          <div className="grid gap-2">
            <Label htmlFor="koleksi-select">Koleksi</Label>
            <select
              id="koleksi-select"
              value={order.collectionId}
              onChange={(event) => order.selectCollection(event.target.value)}
              className="h-11 w-full rounded-md border border-border bg-elevated px-3 text-sm text-fg outline-none focus-visible:border-primary focus-visible:ring-2 focus-visible:ring-primary/20"
            >
              {COLLECTIONS.map((item) => (
                <option key={item.id} value={item.id}>
                  {item.name} · {item.style} · {formatRupiah(item.pricePerMeter)}/m
                </option>
              ))}
            </select>
          </div>

          <div className="grid gap-2">
            <Label>Layout dapur</Label>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-5">
              {LAYOUTS.map((item) => {
                const active = order.layout === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => order.patch({ layout: item.id })}
                    className={cn(
                      "flex min-h-24 flex-col items-center justify-center gap-1 rounded-lg border px-2 py-3 text-center transition-colors duration-[var(--motion-quick)]",
                      active
                        ? "border-primary bg-primary text-primary-fg"
                        : "border-border bg-bg text-muted hover:text-fg",
                    )}
                  >
                    <LayoutIcon type={item.id} />
                    <span className="text-sm font-medium">{item.label}</span>
                    <span className={cn("text-xs", active ? "text-primary-fg/70" : "text-faint")}>
                      {item.hint}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="grid gap-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="panjang">Panjang kabinet</Label>
              <span className="text-sm font-medium tabular-nums">{lengthLabel} m</span>
            </div>
            <div className="flex items-center gap-2">
              <Button
                type="button"
                variant="outline"
                size="icon"
                aria-label="Kurangi setengah meter"
                onClick={() => order.patch({ lengthM: clampLength(order.lengthM - STEP) })}
              >
                <Minus />
              </Button>
              <Input
                id="panjang"
                type="number"
                min={MIN_LENGTH}
                max={MAX_LENGTH}
                step={STEP}
                inputMode="decimal"
                value={order.lengthM}
                onChange={(event) => {
                  const next = Number(event.target.value);
                  if (Number.isFinite(next)) order.patch({ lengthM: clampLength(next) });
                }}
                className="text-center tabular-nums"
              />
              <Button
                type="button"
                variant="outline"
                size="icon"
                aria-label="Tambah setengah meter"
                onClick={() => order.patch({ lengthM: clampLength(order.lengthM + STEP) })}
              >
                <Plus />
              </Button>
            </div>
            <p className="text-xs text-muted">
              Ukur sisi dinding yang akan dipasang kabinet, dari ujung ke ujung.
            </p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div className="grid gap-2">
              <Label htmlFor="nama">Nama</Label>
              <Input
                id="nama"
                autoComplete="name"
                placeholder="Nama pemesan"
                value={order.name}
                onChange={(event) => order.patch({ name: event.target.value })}
                aria-invalid={Boolean(errors.name)}
              />
              {errors.name ? <p className="text-xs font-medium text-fg">{errors.name}</p> : null}
            </div>
            <div className="grid gap-2">
              <Label htmlFor="kota">Kota / area</Label>
              <Input
                id="kota"
                autoComplete="address-level2"
                placeholder="Contoh: Tangerang Selatan"
                value={order.city}
                onChange={(event) => order.patch({ city: event.target.value })}
                aria-invalid={Boolean(errors.city)}
              />
              {errors.city ? <p className="text-xs font-medium text-fg">{errors.city}</p> : null}
            </div>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="catatan">Catatan dapur</Label>
            <Textarea
              id="catatan"
              placeholder="Ukuran ruangan, posisi jendela, mau island, atau warna custom."
              value={order.notes}
              onChange={(event) => order.patch({ notes: event.target.value })}
            />
          </div>

          <Button type="submit" size="lg" className="w-full">
            <Instagram />
            Pesan via Instagram
          </Button>
        </form>

        <aside className="rounded-2xl border border-border bg-elevated lg:sticky lg:top-24 lg:col-span-2">
          <div className="relative aspect-photo overflow-hidden rounded-t-2xl bg-surface">
            <img src={collection.image} alt={collection.alt} className="size-full object-cover" />
          </div>
          <div className="flex flex-col gap-4 p-5">
            <div>
              <p className="text-xs font-medium uppercase tracking-label text-muted">Estimasi</p>
              <h3 className="mt-1 font-display text-2xl font-medium tracking-tight">
                {collection.name}
              </h3>
              <p className="text-sm text-muted">
                {collection.style} · {collection.finish} · {layout.label}
              </p>
            </div>
            <p className="font-display text-3xl font-medium tabular-nums tracking-tight">
              {formatRupiah(estimate)}
            </p>
            <p className="text-xs leading-relaxed text-muted">
              {lengthLabel} m × {formatRupiah(collection.pricePerMeter)}. Belum termasuk top table,
              ongkir, dan pekerjaan sipil. Harga final setelah survey.
            </p>

            {draft ? (
              <div className="rounded-lg border border-border bg-bg p-3">
                <p className="flex items-center gap-2 text-sm font-medium">
                  {copied ? <Check className="size-4" /> : <Copy className="size-4" />}
                  {copied ? "Ringkasan sudah disalin" : "Salin ringkasan, lalu buka DM"}
                </p>
                <pre className="mt-2 max-h-40 overflow-auto whitespace-pre-wrap font-sans text-xs leading-relaxed text-muted">
                  {draft}
                </pre>
                <div className="mt-3 grid gap-2">
                  <Button type="button" variant="outline" onClick={recopy}>
                    <Copy />
                    Salin ulang
                  </Button>
                  <Button asChild>
                    <a href={INSTAGRAM_DM_URL} target="_blank" rel="noreferrer">
                      <Instagram />
                      Buka DM Instagram
                    </a>
                  </Button>
                </div>
              </div>
            ) : (
              <p className="text-sm text-muted">
                Isi nama dan kota, lalu kirim. Studio membalas di Instagram.
              </p>
            )}
          </div>
        </aside>
      </div>
    </section>
  );
}
