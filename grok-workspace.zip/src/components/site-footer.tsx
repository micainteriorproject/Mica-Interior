import { Instagram } from "lucide-react";
import { INSTAGRAM_HANDLE, INSTAGRAM_URL } from "@/lib/kitchen";

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-fg text-bg">
      <div className="mx-auto flex max-w-6xl flex-col gap-8 px-4 py-12 sm:px-6 sm:py-16">
        <div className="flex flex-col justify-between gap-8 sm:flex-row sm:items-end">
          <div>
            <p className="font-display text-3xl font-medium tracking-tight">Mica Interior</p>
            <p className="mt-1 text-xs font-medium uppercase tracking-label text-bg/60">Project</p>
            <p className="mt-2 max-w-sm text-sm leading-relaxed text-bg/70">
              Studio kitchen set custom. Produksi di Tangerang, survey Jabodetabek, pemesanan
              lewat Instagram.
            </p>
          </div>
          <a
            href={INSTAGRAM_URL}
            target="_blank"
            rel="noreferrer"
            className="inline-flex h-11 items-center gap-2 text-sm font-medium text-bg hover:opacity-80"
          >
            <Instagram className="size-4" />
            @{INSTAGRAM_HANDLE}
          </a>
        </div>
        <p className="text-xs text-bg/50">
          Estimasi di situs ini adalah acuan kabinet. Harga final setelah pengukuran.
        </p>
      </div>
    </footer>
  );
}
