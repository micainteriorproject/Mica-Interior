import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { COLLECTIONS, STYLES, formatRupiah, type StyleFilter } from "@/lib/kitchen";
import { useOrder } from "@/lib/order-store";
import { cn } from "@/lib/utils";

function scrollToOrder() {
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  document.getElementById("pesan")?.scrollIntoView({ behavior: reduce ? "auto" : "smooth" });
}

export function Collections() {
  const [style, setStyle] = useState<StyleFilter>("Semua");
  const selectedId = useOrder((s) => s.collectionId);
  const selectCollection = useOrder((s) => s.selectCollection);
  const items = COLLECTIONS.filter((item) => style === "Semua" || item.style === style);

  return (
    <section id="koleksi" className="mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24">
      <div className="max-w-xl">
        <p className="text-xs font-medium uppercase tracking-label text-muted">Koleksi</p>
        <h2 className="mt-3 font-display text-3xl font-medium tracking-tight sm:text-4xl">
          Enam dapur, satu alur pesan.
        </h2>
        <p className="mt-3 text-muted">
          Harga mulai dari finishing kabinet per meter. Top table, handle, dan pekerjaan sipil
          dihitung setelah survey.
        </p>
      </div>

      <div className="-mx-4 mt-8 flex gap-2 overflow-x-auto px-4 pb-1 sm:mx-0 sm:flex-wrap sm:overflow-visible sm:px-0">
        {STYLES.map((item) => (
          <button
            key={item}
            type="button"
            onClick={() => setStyle(item)}
            className={cn(
              "h-11 shrink-0 rounded-full border px-4 text-sm font-medium transition-colors duration-[var(--motion-quick)]",
              style === item
                ? "border-primary bg-primary text-primary-fg"
                : "border-border bg-elevated text-muted hover:text-fg",
            )}
          >
            {item}
          </button>
        ))}
      </div>

      <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((item) => {
          const active = selectedId === item.id;
          return (
            <article
              key={item.id}
              className={cn(
                "flex flex-col overflow-hidden rounded-2xl border bg-elevated transition-colors duration-[var(--motion-fast)]",
                active ? "border-primary" : "border-border",
              )}
            >
              <div className="relative aspect-photo overflow-hidden bg-surface">
                <img
                  src={item.image}
                  alt={item.alt}
                  className="size-full object-cover transition-transform duration-[var(--motion-slow)] ease-[var(--ease-smooth-out)] hover:scale-105"
                />
                <Badge className="absolute left-3 top-3 bg-elevated/95 text-fg">{item.style}</Badge>
              </div>
              <div className="flex flex-1 flex-col gap-4 p-5">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="font-display text-2xl font-medium tracking-tight">{item.name}</h3>
                    <p className="mt-1 text-sm text-muted">
                      {item.finish} · {item.leadWeeks}
                    </p>
                  </div>
                  <p className="text-right text-sm font-medium tabular-nums">
                    {formatRupiah(item.pricePerMeter)}
                    <span className="block text-xs font-normal text-muted">/ meter</span>
                  </p>
                </div>
                <p className="text-sm leading-relaxed text-muted">{item.blurb}</p>
                <Button
                  className="mt-auto w-full"
                  variant={active ? "default" : "outline"}
                  onClick={() => {
                    selectCollection(item.id);
                    scrollToOrder();
                  }}
                >
                  {active ? "Dipilih · lanjut pesan" : "Pesan koleksi ini"}
                </Button>
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}
