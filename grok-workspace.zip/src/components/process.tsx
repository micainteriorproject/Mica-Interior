const steps = [
  {
    n: "01",
    title: "Pilih koleksi",
    body: "Enam finishing siap pakai. Warna dan handle masih bisa disesuaikan setelah survey.",
  },
  {
    n: "02",
    title: "Hitung ukuran",
    body: "Masukkan panjang kabinet. Estimasi muncul langsung, tanpa menunggu chat admin.",
  },
  {
    n: "03",
    title: "Kirim ke Instagram",
    body: "Ringkasan disalin, DM studio terbuka. Tempel, kirim, selesai.",
  },
  {
    n: "04",
    title: "Survey & gambar kerja",
    body: "Tim ukur di lokasi, kunci material, lalu produksi. Jabodetabek survey gratis.",
  },
];

export function Process() {
  return (
    <section id="cara" className="border-y border-border bg-surface">
      <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24">
        <p className="text-xs font-medium uppercase tracking-label text-muted">Cara kerja</p>
        <h2 className="mt-3 max-w-lg font-display text-3xl font-medium tracking-tight sm:text-4xl">
          Dari foto dapur sampai DM, empat langkah.
        </h2>
        <ol className="mt-12 grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {steps.map((step) => (
            <li key={step.n} className="flex flex-col gap-3">
              <span className="font-display text-3xl font-medium text-primary/70">{step.n}</span>
              <h3 className="text-lg font-medium">{step.title}</h3>
              <p className="text-sm leading-relaxed text-muted">{step.body}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
