import { Instagram } from "lucide-react";
import { Button } from "@/components/ui/button";
import { INSTAGRAM_URL } from "@/lib/kitchen";

const links = [
  { href: "#koleksi", label: "Koleksi" },
  { href: "#cara", label: "Cara kerja" },
  { href: "#pesan", label: "Pesan" },
];

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-bg">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4 sm:px-6">
        <a href="#atas" className="flex items-baseline gap-2 text-fg">
          <span className="font-display text-xl font-medium tracking-tight">Mica Interior</span>
          <span className="text-xs font-medium uppercase tracking-label text-muted">
            Project
          </span>
        </a>
        <nav className="hidden items-center gap-8 md:flex" aria-label="Utama">
          {links.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-sm font-medium text-muted transition-colors duration-[var(--motion-quick)] hover:text-fg"
            >
              {link.label}
            </a>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" asChild>
            <a
              href={INSTAGRAM_URL}
              target="_blank"
              rel="noreferrer"
              aria-label="Instagram Mica Interior Project"
            >
              <Instagram />
            </a>
          </Button>
          <Button asChild>
            <a href="#pesan">Pesan</a>
          </Button>
        </div>
      </div>
    </header>
  );
}
