import { ArrowDown } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Hero() {
  return (
    <section id="atas" className="relative h-hero overflow-hidden bg-fg text-bg">
      <img
        src="/kitchens/hero.jpg"
        alt="Dapur japandi Mica Interior Project dengan island batu dan kabinet oak"
        className="absolute inset-0 size-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-fg via-fg/45 to-fg/20" />
      <div className="relative z-10 mx-auto flex h-full max-w-6xl flex-col justify-end gap-6 px-4 pb-12 sm:px-6 sm:pb-16">
        <p className="text-xs font-medium uppercase tracking-label text-bg/80">
          Studio kitchen set · Mica Interior Project
        </p>
        <h1 className="max-w-2xl font-display text-4xl font-medium leading-tight tracking-tight text-bg sm:text-5xl lg:text-6xl">
          Kitchen set custom. Pesan lewat Instagram.
        </h1>
        <p className="max-w-lg text-base leading-relaxed text-bg/80 sm:text-lg">
          Enam koleksi siap pakai. Hitung estimasi per meter, kirim ringkasan ke DM, lalu kami
          survey ke rumah.
        </p>
        <div className="flex flex-col gap-3 sm:flex-row">
          <Button variant="invert" size="lg" asChild>
            <a href="#koleksi">Lihat koleksi</a>
          </Button>
          <Button
            variant="outline"
            size="lg"
            className="border-bg/30 bg-transparent text-bg hover:bg-bg/10"
            asChild
          >
            <a href="#pesan">
              Hitung estimasi
              <ArrowDown />
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
}
