import type { LayoutId } from "@/lib/kitchen";

export function LayoutIcon({ type }: { type: LayoutId }) {
  return (
    <svg viewBox="0 0 32 32" className="size-8" fill="currentColor" aria-hidden="true">
      {type === "lurus" ? <rect x="4" y="13" width="24" height="6" rx="1" /> : null}
      {type === "l" ? (
        <>
          <rect x="4" y="18" width="24" height="6" rx="1" />
          <rect x="4" y="8" width="6" height="16" rx="1" />
        </>
      ) : null}
      {type === "u" ? (
        <>
          <rect x="4" y="20" width="24" height="6" rx="1" />
          <rect x="4" y="8" width="6" height="18" rx="1" />
          <rect x="22" y="8" width="6" height="18" rx="1" />
        </>
      ) : null}
      {type === "paralel" ? (
        <>
          <rect x="4" y="7" width="24" height="6" rx="1" />
          <rect x="4" y="19" width="24" height="6" rx="1" />
        </>
      ) : null}
      {type === "pulau" ? (
        <>
          <rect x="4" y="7" width="24" height="5" rx="1" />
          <rect x="10" y="18" width="12" height="7" rx="1" />
        </>
      ) : null}
    </svg>
  );
}
